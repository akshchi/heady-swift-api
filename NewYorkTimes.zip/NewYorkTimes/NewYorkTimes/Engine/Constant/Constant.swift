//
//  AppConstant.swift
//  NewYorkTimes
//
//  Created by levantAJ on 11/5/18.
//  Copyright © 2018 levantAJ. All rights reserved.
//


/*
 * Use this struct to group all of the constants in the app.
 */
public struct Constant {}
